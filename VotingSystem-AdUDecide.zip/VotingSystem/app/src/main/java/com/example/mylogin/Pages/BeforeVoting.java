package com.example.mylogin.Pages;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.mylogin.R;

public class BeforeVoting extends AppCompatActivity {

    Button btnSignOut, btnVoteNow;
    TextView txtName;
    String firstname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beforevoting);

        btnSignOut = findViewById(R.id.btnSignOut);
        btnVoteNow = findViewById(R.id.btnVoteNow);
        txtName = findViewById(R.id.txtName);
        Intent intent = getIntent();
        firstname = intent.getStringExtra("firstname");
        txtName.setText("Welcome, " + firstname);

        if (getIntent().hasExtra("voted")){
            String voted = getIntent().getStringExtra("voted");
            if (voted.equals("voted")){
                btnVoteNow.setText("Already Voted");
                btnVoteNow.setEnabled(false);
            }
        }

        btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(BeforeVoting.this);
                builder.setMessage("Are you sure you want to logout?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(BeforeVoting.this, LoginRegScreen.class);
                        startActivity(intent);
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.show();


            }
        });

        btnVoteNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BeforeVoting.this, VotingPage.class);
                intent.putExtra("firstname", firstname);
                startActivity(intent);
            }
        });
    }

    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to exit?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(BeforeVoting.this, LoginRegScreen.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.show();
    }
}