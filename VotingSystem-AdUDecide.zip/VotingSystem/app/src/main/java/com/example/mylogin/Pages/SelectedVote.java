package com.example.mylogin.Pages;

public class SelectedVote {
    private String position;
    private String lastName;
    private String firstName;
    private String middleName;

    public SelectedVote(String position, String lastName, String firstName, String middleName) {
        this.position = position;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
    }

    public String getPosition() {
        return position;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }
}
