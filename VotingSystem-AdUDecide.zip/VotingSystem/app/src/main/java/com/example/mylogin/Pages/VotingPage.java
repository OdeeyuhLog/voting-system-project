package com.example.mylogin.Pages;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.mylogin.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class VotingPage extends AppCompatActivity {

    private LinearLayout checkboxContainer;

    private Button btnVote;
    private TextView header, headerhint, progressText;
    private View line;
    private ProgressBar progressBar;
    private Map<String, RadioGroup> radioGroupMap;
    private Map<String, List<Candidate>> candidateMap;
    private Map<String, Integer> selectedCandidatePositions;
    private List<SelectedVote> selectedVotes;
    private String firstname;
    private static final String[] POSITION_ORDER = {
            "President",
            "Vice Internal",
            "Vice External",
            "Secretary",
            "Treasurer",
            "Auditor",
            "P.R.O.",
            "AUSG REP"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_votingpage);
        checkboxContainer = findViewById(R.id.checkboxContainer);
        radioGroupMap = new HashMap<>();
        candidateMap = new HashMap<>();
        selectedCandidatePositions = new HashMap<>();
        selectedVotes = new ArrayList<>();
        Intent intent = getIntent();
        firstname = intent.getStringExtra("firstname");
        makeVolleyRequest();
        header = findViewById(R.id.acomssheader);
        headerhint = findViewById(R.id.headerhint);
        line = findViewById(R.id.line);
        btnVote = findViewById(R.id.btnVote);
        progressBar = findViewById(R.id.progressBar);
        progressText = findViewById(R.id.progressText);
        btnVote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleVoteButtonClick();
            }
        });



    }
    private void handleVoteButtonClick() {
        boolean allPositionsSelected = true;
        for (Map.Entry<String, RadioGroup> entry : radioGroupMap.entrySet()) {
            String position = entry.getKey();
            RadioGroup radioGroup = entry.getValue();

            if (radioGroup.getCheckedRadioButtonId() == -1) {
                Toast.makeText(this, "Please select a candidate for all positions", Toast.LENGTH_SHORT).show();
                allPositionsSelected = false;
                break;
            }

            int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
            RadioButton radioButton = findViewById(checkedRadioButtonId);
            int candidatePosition = (int) radioButton.getTag();

            selectedCandidatePositions.put(position, candidatePosition);

            selectedVotes.removeIf(vote -> vote.getPosition().equals(position));

            selectedVotes.add(new SelectedVote(position, candidateMap.get(position).get(candidatePosition).getLastName(),
                    candidateMap.get(position).get(candidatePosition).getFirstName(),
                    candidateMap.get(position).get(candidatePosition).getMiddleName()));
        }

        if (allPositionsSelected) {
            showConfirmationDialog();
        }
    }

    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are your vote choices final?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                for (SelectedVote selectedVote : selectedVotes) {
                    sendVoteToServer(selectedVote);
                }

                selectedVotes.clear();

                Toast.makeText(VotingPage.this, "Votes submitted successfully", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.show();
    }

    private void sendVoteToServer(SelectedVote selectedVote) {
        String url = "https://adudecide.online/android_vote.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.equals("success")) {
                            Intent intent = new Intent(VotingPage.this, BeforeVoting.class);
                            intent.putExtra("voted", "voted");
                            intent.putExtra("firstname", firstname);
                            btnVote.setEnabled(false);
                            startActivity(intent);
                        }
                        Log.d("VotingResponse", response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(VotingPage.this, "Error submitting vote", Toast.LENGTH_SHORT).show();
                        btnVote.setEnabled(true);
                        Log.e("VotingError", error.toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("lastName", selectedVote.getLastName());
                params.put("firstName", selectedVote.getFirstName());
                params.put("middleName", selectedVote.getMiddleName());
                params.put("position", selectedVote.getPosition());
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }
    private void makeVolleyRequest() {
        String url = "https://adudecide.online/fetchCandidates.php";
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        populateCandidates(response);
                        createCheckboxesAndRadioGroups();
                        btnVote.setVisibility(View.VISIBLE);
                        line.setVisibility(View.VISIBLE);
                        header.setVisibility(View.VISIBLE);
                        headerhint.setVisibility(View.VISIBLE);
                        progressBar.setVisibility(View.GONE);
                        progressText.setVisibility(View.GONE);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(VotingPage.this, "Error retrieving data", Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE);
                    }
                });

        queue.add(jsonObjectRequest);
    }
    private void populateCandidates(JSONObject jsonObject) {
        try {
            Iterator<String> positions = jsonObject.keys();
            while (positions.hasNext()) {
                String position = positions.next();
                JSONArray candidatesArray = jsonObject.getJSONArray(position);

                List<Candidate> candidates = new ArrayList<>();
                for (int i = 0; i < candidatesArray.length(); i++) {
                    JSONObject candidateObject = candidatesArray.getJSONObject(i);

                    Candidate candidate = new Candidate(
                            candidateObject.getString("lastname"),
                            candidateObject.getString("firstname"),
                            candidateObject.getString("middlename"),
                            candidateObject.getString("studnum")
                    );

                    candidates.add(candidate);
                }

                candidateMap.put(position, candidates);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void createCheckboxesAndRadioGroups() {
        for (String position : POSITION_ORDER) {
            if (candidateMap.containsKey(position)) {
                View customCheckboxLayout = getLayoutInflater().inflate(R.layout.custom_checkbox, checkboxContainer, false);
                CheckBox checkBox = customCheckboxLayout.findViewById(R.id.customCheckBox);
                checkBox.setText(position);
                checkboxContainer.addView(customCheckboxLayout);

                RadioGroup radioGroup = new RadioGroup(this);
                radioGroup.setId(View.generateViewId());
                radioGroupMap.put(position, radioGroup);

                checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        String position = buttonView.getText().toString();
                        RadioGroup radioGroup = radioGroupMap.get(position);
                        radioGroup.setVisibility(isChecked ? View.VISIBLE : View.GONE);
                        if (isChecked) {
                            selectedCandidatePositions.put(position, -1);
                            buttonView.setButtonDrawable(R.drawable.checkbox_up);
                        } else {
                            selectedCandidatePositions.remove(position);
                            buttonView.setButtonDrawable(R.drawable.checkbox_down);
                        }
                    }
                });

                radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        RadioButton radioButton = group.findViewById(checkedId);
                        if (radioButton != null && radioButton.isChecked()) {
                            String position = checkBox.getText().toString();
                            int candidatePosition = (int) radioButton.getTag();

                            selectedCandidatePositions.put(position, candidatePosition);

                            selectedVotes.removeIf(vote -> vote.getPosition().equals(position));


                            selectedVotes.add(new SelectedVote(position, candidateMap.get(position).get(candidatePosition).getLastName(),
                                    candidateMap.get(position).get(candidatePosition).getFirstName(),
                                    candidateMap.get(position).get(candidatePosition).getMiddleName()));

                        }
                    }
                });

                checkboxContainer.addView(radioGroup);
                radioGroup.setVisibility(View.GONE);

                for (Candidate candidate : candidateMap.get(position)) {
                    RadioButton radioButton = (RadioButton) getLayoutInflater().inflate(R.layout.custom_radiobutton, null);
                    RadioGroup.LayoutParams layoutParams = new RadioGroup.LayoutParams(
                            RadioGroup.LayoutParams.MATCH_PARENT,
                            RadioGroup.LayoutParams.WRAP_CONTENT
                    );
                    layoutParams.setMargins(35, 15, 35, 15);
                    radioButton.setGravity(Gravity.CENTER_VERTICAL);
                    radioButton.setLayoutParams(layoutParams);
                    radioButton.setHeight(200);
                    radioButton.setText(candidate.getFirstName() + " " + candidate.getMiddleName() + " " + candidate.getLastName());
                    Drawable drawable = getResources().getDrawable(R.drawable.radiono);
                    radioButton.setCompoundDrawablesWithIntrinsicBounds(null, null, drawable, null);
                    radioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            if (isChecked) {
                                Drawable drawable = getResources().getDrawable(R.drawable.radioyes);
                                radioButton.setCompoundDrawablesWithIntrinsicBounds(null, null, drawable, null);

                            } else {
                                Drawable drawable = getResources().getDrawable(R.drawable.radiono);
                                radioButton.setCompoundDrawablesWithIntrinsicBounds(null, null, drawable, null);

                            }

                        }
                    });

                    radioButton.setId(View.generateViewId());
                    radioButton.setTag(candidateMap.get(position).indexOf(candidate));
                    radioGroup.addView(radioButton);


                }

            }
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to go back?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(VotingPage.this, BeforeVoting.class);
                intent.putExtra("firstname", firstname);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.show();
    }

}