package com.example.mylogin.Pages;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.mylogin.R;

import java.util.HashMap;
import java.util.Map;

public class SignUp3 extends AppCompatActivity {

    EditText inpEmailAdd, inpPassword, inpConfirmPass;
    Button btnRegister;
    String firstName, middleName, lastName, suffix, studID, yearLvl, course, email, URL = "https://adudecide.online/android_register.php";
    String[] yearValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up3);

        inpEmailAdd = findViewById(R.id.inpEmailAdd);
        inpPassword = findViewById(R.id.inpPassword);
        inpConfirmPass = findViewById(R.id.inpConfirmPass);
        btnRegister = findViewById(R.id.btnRegister);

        yearValues = getApplicationContext().getResources().getStringArray(R.array.yearlevel);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setAllData();
                btnRegister.setEnabled(false);
                if (firstName.equals("") || middleName.equals("") || lastName.equals("") ||
                        studID.equals("") || yearLvl.equals("") || course.equals("")) {
                    Toast.makeText(SignUp3.this, "Please fill up all fields", Toast.LENGTH_SHORT).show();
                    btnRegister.setEnabled(true);
                } else {
                    String password = inpPassword.getText().toString();
                    String confirmPass = inpConfirmPass.getText().toString();

                    if (password.equals(confirmPass)) {

                        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if (response.equals("success")) {
                                    Intent intent = new Intent(SignUp3.this, LoginRegScreen.class);
                                    startActivity(intent);
                                } else if (response.equals("failed")) {
                                    btnRegister.setEnabled(true);
                                    Toast.makeText(SignUp3.this, "Something went wrong!", Toast.LENGTH_SHORT).show();
                                }
                                else if(response.equals("Same Entry")){
                                    btnRegister.setEnabled(true);
                                    Toast.makeText(SignUp3.this, "Similar Entry Found!", Toast.LENGTH_SHORT).show();
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                btnRegister.setEnabled(true);
                                Log.e("VolleyError", "Error during registering", error);
                                Toast.makeText(SignUp3.this, "An error occurred. Please try again later.", Toast.LENGTH_SHORT).show();
                            }
                        }){
                            @Nullable
                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                String[] fields = {"lastname", "firstname", "middlename", "suffix", "email", "password",  "course", "yearlevel", "stud_id"};
                                Map<String, String> data = new HashMap<>();
                                for (int i = 0; i < fields.length; i++) {
                                    switch (fields[i]) {
                                        case "lastname":
                                            data.put(fields[i], lastName);
                                            break;
                                        case "firstname":
                                            data.put(fields[i], firstName);
                                            break;
                                        case "middlename":
                                            data.put(fields[i], middleName);
                                            break;
                                        case "suffix":
                                            data.put(fields[i], suffix);
                                            break;
                                        case "email":
                                            data.put(fields[i], email);
                                            break;
                                        case "password":
                                            data.put(fields[i], password);
                                            break;
                                        case "course":
                                            data.put(fields[i], course);
                                            break;
                                        case "yearlevel":
                                            data.put(fields[i], yearLvl);
                                            break;
                                        case "stud_id":
                                            data.put(fields[i], studID);
                                            break;
                                    }
                                }

                                return data;
                            }
                        };
                        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                        requestQueue.add(stringRequest);



                    }
                    else {
                        Toast.makeText(SignUp3.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        if (getIntent().hasExtra("email") || getIntent().hasExtra("password") || getIntent().hasExtra("confirmPass")) {
            String email = getIntent().getStringExtra("email");
            String password = getIntent().getStringExtra("password");
            String confirmPass = getIntent().getStringExtra("confirmPass");

            inpEmailAdd.setText(email);
            inpPassword.setText(password);
            inpConfirmPass.setText(confirmPass);
        }


        inpEmailAdd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                // Check validation when the focus is lost (user moves away from inpEmailAdd)
                if (!hasFocus) {
                    String email = inpEmailAdd.getText().toString().trim().toLowerCase();
                    if (email.endsWith("@adamson.edu.ph")) {
                        btnRegister.setEnabled(true);
                    } else {
                        // Display a toast or take any other action to notify the user
                        Toast.makeText(SignUp3.this, "Use AdU Email", Toast.LENGTH_SHORT).show();
                        btnRegister.setEnabled(false);
                    }
                }
            }
        });


    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(SignUp3.this, SignUp2.class);

        intent.putExtra("inpEmailAdd", inpEmailAdd.getText().toString());
        intent.putExtra("inpPassword", inpPassword.getText().toString());
        intent.putExtra("inpConfirmPass", inpConfirmPass.getText().toString());

        if (getIntent().hasExtra("inpStudID") || getIntent().hasExtra("inpYearLvl") ||
                getIntent().hasExtra("inpCourse")) {

            String getStudID = getIntent().getStringExtra("inpStudID");
            String getYearLvl = getIntent().getStringExtra("inpYearLvl");
            String getCourse = getIntent().getStringExtra("inpCourse");

            intent.putExtra("StudID", getStudID);
            intent.putExtra("YearLvl", getYearLvl);
            intent.putExtra("Course", getCourse);
        }

        if (getIntent().hasExtra("firstName") || getIntent().hasExtra("middleName") ||
                getIntent().hasExtra("lastName") || getIntent().hasExtra("suffix")) {

            String getFirstName = getIntent().getStringExtra("firstName");
            String getMiddleName = getIntent().getStringExtra("middleName");
            String getLastName = getIntent().getStringExtra("lastName");
            String getSuffix = getIntent().getStringExtra("suffix");

            intent.putExtra("inpFirstN", getFirstName);
            intent.putExtra("inpMiddleN", getMiddleName);
            intent.putExtra("inpLastN", getLastName);
            intent.putExtra("inpSuffix", getSuffix);
        }

        startActivity(intent);
    }

    public void setAllData() {
        String getFirstName = getIntent().getStringExtra("firstName");
        String getMiddleName = getIntent().getStringExtra("middleName");
        String getLastName = getIntent().getStringExtra("lastName");
        String getSuffix = getIntent().getStringExtra("suffix");
        String getStudID = getIntent().getStringExtra("inpStudID");
        String getYearLvl = getIntent().getStringExtra("inpYearLvl");
        String getCourse = getIntent().getStringExtra("inpCourse");

        int selectedYear = Integer.parseInt(getYearLvl);
        String selectedYearString = yearValues[selectedYear];

        firstName = getFirstName;
        middleName = getMiddleName;
        lastName = getLastName;
        suffix = getSuffix;
        studID = getStudID;
        yearLvl = selectedYearString;
        course = getCourse;
        email = inpEmailAdd.getText().toString();
    }

}