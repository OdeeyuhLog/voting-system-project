package com.example.mylogin.Pages;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.mylogin.R;

import java.util.HashMap;
import java.util.Map;

public class LoginRegScreen extends AppCompatActivity {

    Button btnSignUp, btnSignIn;
    EditText email, password;
    String inpEmail, inpPass, URL = "https://adudecide.online/android_login.php";

    ImageButton passEye;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginregscreen);

        btnSignUp = findViewById(R.id.btnSignUp);
        btnSignIn = findViewById(R.id.btnSignIn);
        password = findViewById(R.id.password);
        email = findViewById(R.id.email);
        passEye = findViewById(R.id.passEye);

        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String emailText = editable.toString();
                Drawable drawable = null;

                if (emailText.contains("@adamson.edu.ph")) {
                    drawable = getResources().getDrawable(R.drawable.done_icon);
                }

                email.setCompoundDrawablesWithIntrinsicBounds(null, null, drawable, null);
            }
        });


        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inpEmail = email.getText().toString().trim();
                inpPass = password.getText().toString().trim();

                if (!inpEmail.equals("") && !inpPass.equals("")) {
                    btnSignIn.setEnabled(false);

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            String[] responseData = response.split("\\|");

                            if (responseData.length > 0) {
                                if (responseData[0].equals("approved")) {
                                    String firstname = (responseData.length > 1) ? responseData[1].trim() : "";
                                    Log.d("Response", "Firstname: " + firstname);
                                    Intent intent = new Intent(LoginRegScreen.this, BeforeVoting.class);
                                    intent.putExtra("firstname", firstname);
                                    startActivity(intent);
                                    finish();
                                } else if (responseData[0].equals("User not found!") || responseData[0].equals("Invalid password or email!")) {
                                    Toast.makeText(LoginRegScreen.this, "Wrong Username or Password", Toast.LENGTH_SHORT).show();
                                    btnSignIn.setEnabled(true);
                                } else if (responseData[0].equals("pending")) {
                                    Toast.makeText(LoginRegScreen.this, "Pending admin approval", Toast.LENGTH_SHORT).show();
                                    btnSignIn.setEnabled(true);
                                } else {
                                    Toast.makeText(LoginRegScreen.this, "Rejected", Toast.LENGTH_SHORT).show();
                                    btnSignIn.setEnabled(true);
                                }
                            } else {
                                Toast.makeText(LoginRegScreen.this, "Invalid response format", Toast.LENGTH_SHORT).show();
                                btnSignIn.setEnabled(true);
                            }
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            btnSignIn.setEnabled(true);
                            Log.e("VolleyError", "Error during sign-in", error);
                            Toast.makeText(LoginRegScreen.this, "An error occurred. Please try again later.", Toast.LENGTH_SHORT).show();
                        }
                    }) {
                        @Nullable
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> data = new HashMap<>();
                            data.put("email", inpEmail);
                            data.put("password", inpPass);
                            return data;
                        }
                    };
                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                    requestQueue.add(stringRequest);
                } else {
                    Toast.makeText(LoginRegScreen.this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                }
            }
        });

        passEye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility();
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginRegScreen.this, SignUp1.class);
                startActivity(intent);
            }
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!passEye.isSelected()) {
                    password.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
                } else {
                    password.setTransformationMethod(null);
                }
            }
        });
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void togglePasswordVisibility() {
        passEye.setSelected(!passEye.isSelected());

        if (!passEye.isSelected()) {
            password.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
            int colorResId = R.color.darkgrey;
            passEye.setColorFilter(ContextCompat.getColor(getApplicationContext(), colorResId));
        } else {
            password.setTransformationMethod(null);
            int colorResId = R.color.lightgreen;
            passEye.setColorFilter(ContextCompat.getColor(getApplicationContext(), colorResId));
        }

        password.setSelection(password.getText().length());
    }
}


