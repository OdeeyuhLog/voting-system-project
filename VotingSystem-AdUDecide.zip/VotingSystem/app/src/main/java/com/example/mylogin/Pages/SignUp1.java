package com.example.mylogin.Pages;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.mylogin.R;

public class SignUp1 extends AppCompatActivity {

    EditText inpFirstN, inpMiddleN, inpLastN, inpSuffix;
    Button btnContinue;
    String StudID, YearLvl, Course;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up1);

        inpFirstN = findViewById(R.id.inpFirstN);
        inpMiddleN = findViewById(R.id.inpMiddleN);
        inpLastN = findViewById(R.id.inpLastN);
        inpSuffix = findViewById(R.id.inpSuffix);

        btnContinue = findViewById(R.id.btnContinue);
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(SignUp1.this, SignUp2.class);
                // Store SignUp1 data to SignUp2
                intent.putExtra("inpFirstN", String.valueOf(inpFirstN.getText()));
                intent.putExtra("inpMiddleN", String.valueOf(inpMiddleN.getText()));
                intent.putExtra("inpLastN", String.valueOf(inpLastN.getText()));
                intent.putExtra("inpSuffix", String.valueOf(inpSuffix.getText()));

                // Give back the data from input fields on SignUp2
                if (getIntent().hasExtra("inpStudID") || getIntent().hasExtra("inpYearLvl") || getIntent().hasExtra("inpCourse")) {
                    StudID = getIntent().getStringExtra("inpStudID");
                    YearLvl = getIntent().getStringExtra("inpYearLvl");
                    Course = getIntent().getStringExtra("inpCourse");


                    intent.putExtra("StudID", String.valueOf(StudID));
                    intent.putExtra("YearLvl", String.valueOf(YearLvl));
                    intent.putExtra("Course", String.valueOf(Course));
                }

                // Put data from SignUp3 back to SignUp2
                if(getIntent().hasExtra("email") || getIntent().hasExtra("password") || getIntent().hasExtra("confirmPass")) {
                    String email = getIntent().getStringExtra("email");
                    String password = getIntent().getStringExtra("password");
                    String confirmPass = getIntent().getStringExtra("confirmPass");

                    intent.putExtra("inpEmailAdd", String.valueOf(email));
                    intent.putExtra("inpPassword", String.valueOf(password));
                    intent.putExtra("inpConfirmPass", String.valueOf(confirmPass));
                }
                        startActivity(intent);
            }
        });


        //Get SignUp1 data from SignUp2 and set the TextFields to the corresponding value
        if (getIntent().hasExtra("firstName") || getIntent().hasExtra("middleName") || getIntent().hasExtra("lastName")
                || getIntent().hasExtra("suffix")) {

           String getFirstN = getIntent().getStringExtra("firstName");
           String getMiddleN = getIntent().getStringExtra("middleName");
           String getLastN = getIntent().getStringExtra("lastName");
           String getSuffix = getIntent().getStringExtra("suffix");

            inpFirstN.setText(getFirstN);
            inpMiddleN.setText(getMiddleN);
            inpLastN.setText(getLastN);
            inpSuffix.setText(getSuffix);

        }

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, LoginRegScreen.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}