package com.example.mylogin.Pages;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import com.example.mylogin.R;

public class SignUp2 extends AppCompatActivity {

    EditText inpStudID, inpCourse;
    Spinner inpYearLvl;
    Button btnContinue;

    String firstName, middleName, lastName, suffix;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up2);

        inpStudID = findViewById(R.id.inpStudID);
        inpYearLvl = findViewById(R.id.inpYearLvl);
        inpCourse = findViewById(R.id.inpCourse);
        btnContinue = findViewById(R.id.btnContinue);

        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUp2.this, SignUp3.class);

                intent.putExtra("inpStudID", inpStudID.getText().toString());
                intent.putExtra("inpYearLvl", String.valueOf(inpYearLvl.getSelectedItemPosition()));
                intent.putExtra("inpCourse", inpCourse.getText().toString());

                if (getIntent().hasExtra("inpFirstN") || getIntent().hasExtra("inpMiddleN") ||
                        getIntent().hasExtra("inpLastN") || getIntent().hasExtra("inpSuffix")) {

                    firstName = getIntent().getStringExtra("inpFirstN");
                    middleName = getIntent().getStringExtra("inpMiddleN");
                    lastName = getIntent().getStringExtra("inpLastN");
                    suffix = getIntent().getStringExtra("inpSuffix");

                    intent.putExtra("firstName", firstName);
                    intent.putExtra("middleName", middleName);
                    intent.putExtra("lastName", lastName);
                    intent.putExtra("suffix", suffix);
                }

                if (getIntent().hasExtra("inpEmailAdd") || getIntent().hasExtra("inpPassword") ||
                        getIntent().hasExtra("inpConfirmPass")) {

                    String getEmailAdd = getIntent().getStringExtra("inpEmailAdd");
                    String getPassword = getIntent().getStringExtra("inpPassword");
                    String getConfirmPass = getIntent().getStringExtra("inpConfirmPass");

                    intent.putExtra("email", getEmailAdd);
                    intent.putExtra("password", getPassword);
                    intent.putExtra("confirmPass", getConfirmPass);
                }

                startActivity(intent);
            }
        });

        if (getIntent().hasExtra("StudID") || getIntent().hasExtra("YearLvl") || getIntent().hasExtra("Course")) {
            String getStudID = getIntent().getStringExtra("StudID");
            String getYearLvl = getIntent().getStringExtra("YearLvl");
            String getCourse = getIntent().getStringExtra("Course");

            int selectedYearLvl = Integer.parseInt(getYearLvl);

            inpStudID.setText(getStudID);
            inpYearLvl.setSelection(selectedYearLvl);
            inpCourse.setText(getCourse);
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(SignUp2.this, SignUp1.class);

        if (getIntent().hasExtra("inpFirstN") || getIntent().hasExtra("inpMiddleN") ||
                getIntent().hasExtra("inpLastN") || getIntent().hasExtra("inpSuffix")) {

            firstName = getIntent().getStringExtra("inpFirstN");
            middleName = getIntent().getStringExtra("inpMiddleN");
            lastName = getIntent().getStringExtra("inpLastN");
            suffix = getIntent().getStringExtra("inpSuffix");

            intent.putExtra("firstName", firstName);
            intent.putExtra("middleName", middleName);
            intent.putExtra("lastName", lastName);
            intent.putExtra("suffix", suffix);
        }

        if (getIntent().hasExtra("inpEmailAdd") || getIntent().hasExtra("inpPassword") ||
                getIntent().hasExtra("inpConfirmPass")) {

            String getEmailAdd = getIntent().getStringExtra("inpEmailAdd");
            String getPassword = getIntent().getStringExtra("inpPassword");
            String getConfirmPass = getIntent().getStringExtra("inpConfirmPass");

            intent.putExtra("email", getEmailAdd);
            intent.putExtra("password", getPassword);
            intent.putExtra("confirmPass", getConfirmPass);
        }

        intent.putExtra("inpStudID", inpStudID.getText().toString());
        intent.putExtra("inpYearLvl", String.valueOf(inpYearLvl.getSelectedItemPosition()));
        intent.putExtra("inpCourse", inpCourse.getText().toString());

        startActivity(intent);
    }
}